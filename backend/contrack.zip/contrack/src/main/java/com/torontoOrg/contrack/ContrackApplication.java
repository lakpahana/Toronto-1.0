package com.torontoOrg.contrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContrackApplication.class, args);
	}

}
