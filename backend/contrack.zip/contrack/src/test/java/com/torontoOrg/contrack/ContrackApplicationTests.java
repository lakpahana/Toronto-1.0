package com.torontoOrg.contrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
